const crypto = require('crypto');

const alicePublicKey = `-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwd+f8YMncA/KIiyDz5wF
dKmXnB3YeQzDHmWaqq6CGNVEQGlmM8NVFOgNrVpM7NbUeJ1V5XnWxeyqG4gOejTY
LDpSL99qnrU13N9/m1csxDuJwCLzoEwHsOSjaiVUsZuIyLTsQZyZnWMSuIj3Otq6
+rv3BnBM0Vt5MZV7V6vfJubjqQqKFyeYM2H/zw3hRcSkXQzl7cSt+sYep5NJZ2PW
eykkUwa0o3dXuLIJLJ4pjW7h/GH/MmrxM+ye8MymYByyPppJmvnXFG6VdpOhLv+e
V4R2LztLV9n5X69ItN6D108r9Pt9tTP57c0y/k5u/99fuxJLSNIIVD5ygeQ2Ra8x
XQIDAQAB
-----END PUBLIC KEY-----`;

const alicePrivateKey = `-----BEGIN PRIVATE KEY-----
MIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQDB35/xgydwD8oi
LIPPnAV0qZecHdh5DMMeZZqqroIY1URAaWYzw1UU6A2tWkzs1tR4nVXledbF7Kob
iA56NNgsOlIv32qetTXc33+bVyzEO4nAIvOgTAew5KNqJVSxm4jItOxBnJmdYxK4
iPc62rr6u/cGcEzRW3kxlXtXq98m5uOpCooXJ5gzYf/PDeFFxKRdDOXtxK36xh6n
k0lnY9Z7KSRTBrSjd1e4sgksnimNbuH8Yf8yavEz7J7wzKZgHLI+mkma+dcUbpV2
k6Eu/55XhHYvO0tX2flfr0i03oPXTyv0+321M/ntzTL+Tm7/31+7EktI0ghUPnKB
5DZFrzFdAgMBAAECggEAFb+4ead07SVYT60evFOMaSH9WA4hErNT0D0ltLAO+Co0
leU9CeGH0eiWYDQZHRicjUtZL30TkvCRxLTmqt7ywUNppOUzWMqLWFPaRNrqsrjb
IyrImdrtofKEQowdjC8ekSV6u4GN2hIbL4ht87RF9YrQk3BVrcbNObrDM3qcdgiO
cHPf6S25b8qBBdGdaulloSeospo27gI9HqgL7Rou8ynbyAuL+dAQ1B4CYmdfgUG4
TcNv9mMgt17PWfduH/cqdth2nQ2t6a6+EBQuPfzjrYzk039JcHMVqPDRDgRZsNUP
tQ6QRFICCU3RL8iIMQNy5l2jCz7x1zfXiS+CwzYNAQKBgQD8mdiL3maJCLu10jHN
dg3ULioga8V7jE9GZpVhzxSb7Xu8/ntXJFipWoHOlbzDRC4Mlx05MCTljiBDkaCa
XFqSgA4Hf3US+u+ddzJCX4yRVEo/fnbGlo+UldS5rpPL2QhMfvDA7xamNFuk4KdS
ws8lg8aLYGQbiQEnNuyndfVRmQKBgQDEe3nZjcxjqGxRxrn63JG+0saSc7BPZPPP
llS6AoIQlSuhNIhwh+Sl3YhOoa7pvwsENlb1lGl0TPP1HKNE3NqNkVGR3PiLksmh
9mNg9p4rkdUDJIHFHMfQLISxDMoIUVUPlC/hKlF5xbSaLXiXT1JjqKcRxmAZJkVq
dMjmdtYAZQKBgQDXolWzgRWy4ZusaVVOefrwKMCZkKazA2IhTS00o9yKB79b5TpR
d5ugZrztJ/JOFwPgh5fQ3AKDXEK6q7SYUUKYUWyohevhWgn3OGvVMVAEOBpx/XlT
qe/D/evs3tUYbZuiAbNwYCnLlGKva4ArLFY9RjLVhGGxB9HOMhrwEchr8QKBgQC7
vK+k7BRLdPZq/NNfm7m293a9IMVqVy+PPjkesp7McXwKwENOIsqaoZ5IY7zZo61H
DRTx+ij48z53CjIG7m/1rNCf6t+hnVQD6YTzdTGUt/cs1YkZanKRurfe5DV21R/N
ju5g2yqWjA4Q8zmyehxjFRbtqPrRjPvuyD/d1daM8QKBgQDZw7WMv9H4TWlVvelL
Kh4MkenFCr33juya6Vk1Xr42HJM04IfmoDzHzO7sr6GGIHmBQS3NiJJyJAVBJ5nP
nZIXzPOwfvY7T6qsX3DBqoLDtfnkVNr+BaMdYuOX22wkcPpVbSIFBmzF3FDcjtp6
g/HFXQKKKx+pg/YM+aO2yMD//Q==
-----END PRIVATE KEY-----`;

const bobPublicKey = `-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAuHOZi9Uj0YwvLdVX8c8l
QjrL4rgAT3t8/ckzVwJBpzQfb7bfuwa/uSDe2eai0f2n/JIFL1jo2fRyom877zKd
+c2BDl1C3b7cgJu8JKxvYKPfA63l3uNgZ9xWpve3ISez07btiTg8lLJ1DiW1bw0N
fr+Mb7CYam651MqkMOg49Fi5SjGKtVB0yr3tr0g1qrwIMa6oE/aL+CTBzbRtS6Pi
3j4KOwk5zf0ujXASXOhjyDUcByvjWjz0t56wPqbt8SKoYSf7mW/LY7UIwiSNh6zQ
dQ1468SOUTuIaswUsw8/wMAck8SVQIL3llG6inkKJUJ+wt0dk5D+twMuxOK4fyue
qwIDAQAB
-----END PUBLIC KEY-----`;

const message = "I want some apples";  

const sign = crypto.createSign('SHA256');  
sign.update(message);  
sign.end();  
const signature = sign.sign(alicePrivateKey, 'hex'); 

const encryptedMessage = crypto.publicEncrypt(bobPublicKey, Buffer.from(message)).toString('hex');  

console.log("Signature:", signature);
console.log("Message:", encryptedMessage);
